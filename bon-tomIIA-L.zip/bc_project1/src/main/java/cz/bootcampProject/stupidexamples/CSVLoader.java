/**
 * 
 */
package cz.bootcampProject.stupidexamples;

/**
 * @author tomas.majda
 *
 */
public class CSVLoader {

}
