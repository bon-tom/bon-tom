/**
 * 
 */
package cz.bootcampProject.entities;

/**
 * @author tomas.majda
 *
 */
public class transactions {

}
