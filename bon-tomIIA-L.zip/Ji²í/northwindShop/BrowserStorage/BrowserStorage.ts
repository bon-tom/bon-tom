namespace sffw.api.browserStorage {
    export class BrowserStorage {
        private storage: Storage;

        constructor(datacontext: IGeneratedDataContext, args: { sessionOnly: boolean }) {
            if (window) {
                this.storage = args.sessionOnly ? window.sessionStorage : window.localStorage;
            }
        }

        public getItem(args: {key: string}): string {
            if (this.storage) {
                return this.storage.getItem(args.key);
            }
            return null;
        }

        // returns false if method was not successful either because storage is not available or quota was exceeded
        public setItem(args: {key: string, value: string}): void {
            if (this.storage) {
                try {
                    this.storage.setItem(args.key, args.value);
                } catch (err) {
                    // quota was possibly exceeded; do nothing
                }
            }
        }

        public removeItem(args: {key: string}): void {
            if (this.storage) {
                this.storage.removeItem(args.key);
            }
        }

        public clear(): void {
            if (this.storage) {
                this.storage.clear();
            }
        }
    }
}

if (typeof define !== 'undefined') {
    define([], () => {
        return sffw.api.browserStorage.BrowserStorage;
    });
}