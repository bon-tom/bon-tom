import Record from './Record';
export default class Movie extends Record {

}