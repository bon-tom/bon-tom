import Record from './Record';
export default class Series extends Record {

}