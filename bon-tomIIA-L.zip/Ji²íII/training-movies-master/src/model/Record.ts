export default class Record {

}